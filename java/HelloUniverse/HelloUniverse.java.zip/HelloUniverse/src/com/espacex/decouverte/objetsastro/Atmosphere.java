package com.espacex.decouverte.objetsastro;

import java.util.HashMap;
import java.util.Map;

public class Atmosphere {

    public Map <String, Float> constituants = new HashMap();
}
