package com.espacex.decouverte.objetsastro;

import java.util.Set;
import java.util.TreeSet;

public class Galaxie {

    public String nom;
    public Set<Planete> planetes = new TreeSet();
}
