package com.espacex.decouverte.objetsastro;

import com.espacex.decouverte.enginsspatiaux.Vaisseau;

public interface Habitable {

    public void accueillirVaisseaux(Vaisseau... nouveauVaisseau);
}
