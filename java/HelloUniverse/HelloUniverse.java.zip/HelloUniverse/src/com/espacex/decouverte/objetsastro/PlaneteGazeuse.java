package com.espacex.decouverte.objetsastro;

public class PlaneteGazeuse extends Planete{

    public PlaneteGazeuse(String nom){
        super(nom);
    }

}
