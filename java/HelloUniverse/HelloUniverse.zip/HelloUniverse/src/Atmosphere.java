public class Atmosphere {

    float tauxHydrogene;
    float tauxMethane;
    float tauxAzote;
    float tauxHelium;
    float tauxArgon;
    float tauxDioxydeCarbone;
    float tauxSodium;
    float tauxOxygene;
}
