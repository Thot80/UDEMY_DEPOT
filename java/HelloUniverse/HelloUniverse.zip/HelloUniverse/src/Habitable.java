public interface Habitable {

    public Vaisseau accueillirVaisseau(Vaisseau nouveauVaisseau);
}
