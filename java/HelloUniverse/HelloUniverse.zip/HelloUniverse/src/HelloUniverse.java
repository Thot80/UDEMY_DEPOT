public class HelloUniverse {

    public static void main(String... args) {

        PlaneteTellurique mercure = new PlaneteTellurique("Mercure");
        mercure.diametre = 4880;
        mercure.atmosphere.tauxOxygene = 42;
        mercure.atmosphere.tauxSodium = 29;
        mercure.atmosphere.tauxHydrogene = 22;


        PlaneteTellurique venus = new PlaneteTellurique("Venus");
        venus.diametre = 12100;
        venus.atmosphere.tauxDioxydeCarbone = 96;
        venus.atmosphere.tauxAzote = 3;

        PlaneteTellurique terre = new PlaneteTellurique("Terre");
        terre.diametre = 12756;
        terre.atmosphere.tauxAzote = 78;
        terre.atmosphere.tauxOxygene = 21;
        terre.atmosphere.tauxArgon = 1;

        PlaneteTellurique mars = new PlaneteTellurique("Mars");
        mars.diametre = 6792;
        mars.atmosphere.tauxDioxydeCarbone = 95;
        mars.atmosphere.tauxAzote = 3;
        mars.atmosphere.tauxArgon = 1.5f;

        PlaneteGazeuse jupiter = new PlaneteGazeuse("Jupiter");
        jupiter.diametre = 142984;
        jupiter.atmosphere.tauxHydrogene = 90;
        jupiter.atmosphere.tauxHelium = 10;

        PlaneteGazeuse saturne = new PlaneteGazeuse("Saturne");
        saturne.diametre = 120536;
        saturne.atmosphere.tauxHelium = 3;
        saturne.atmosphere.tauxHydrogene = 96;

        PlaneteGazeuse uranus = new PlaneteGazeuse("Uranus");
        uranus.diametre = 51118;
        uranus.atmosphere.tauxHydrogene = 83;
        uranus.atmosphere.tauxHelium = 15;
        uranus.atmosphere.tauxMethane = 2.5f;

        PlaneteGazeuse neptune = new PlaneteGazeuse("Neptune");
        neptune.diametre = 49532;
        neptune.atmosphere.tauxHydrogene = 80;
        neptune.atmosphere.tauxHelium = 19;
        neptune.atmosphere.tauxMethane = 1;


        int nbreTourNeptune = neptune.revolution(-3542);
        System.out.println("Neptune à effectuée " + nbreTourNeptune + " tours autour complets de son étoile.");

        int nbreTourMars = mars.rotation(-684);
        System.out.println("Mars à effectué " + nbreTourMars + " tours complets sur elle-même.");

        int nbreTourVenus = venus.rotation(1250);
        System.out.println("Vénus à effectuée " + nbreTourVenus + " tours complets sur elle-même.");


       VaisseauDeGuerre croiseur = new VaisseauDeGuerre("CROISEUR");
       croiseur.nbPassagers = 42;



        System.out.println("La forme d'une planète est : "+Planete.forme);
        System.out.println("La forme de Mars est : "+mars.forme);

        System.out.println("Uranus est composée : ");
        System.out.println("A " +uranus.atmosphere.tauxHydrogene + "% d'hydrogène");
        System.out.println("A " +uranus.atmosphere.tauxHelium + "% d'hélium");
        System.out.println("A " +uranus.atmosphere.tauxMethane + "% de méthane");

        System.out.println(Planete.expansion(10.5));
        System.out.println(Planete.expansion(14.2));

        System.out.println(Planete.nbPlanetesDecouvertes);

        VaisseauDeGuerre chasseur = new VaisseauDeGuerre("Chasseur");
        chasseur.blindage = 156;
        chasseur.resistanceDuBouclier = 2;

        VaisseauCivil vaisseauMonde = new VaisseauCivil("Vaisseau-Monde");
        vaisseauMonde.blindage = 4784;
        vaisseauMonde.resistanceDuBouclier = 30;

        chasseur.activerBouclier();
        vaisseauMonde.activerBouclier();
        chasseur.attaque(vaisseauMonde,"lasers-photoniques", 3);
        vaisseauMonde.desactiverBouclier();
        System.out.println(vaisseauMonde.resistanceDuBouclier);
        System.out.println(vaisseauMonde.blindage);

        mars.accueillirVaisseau(vaisseauMonde);
        mars.accueillirVaisseau(chasseur);

        terre.accueillirVaisseau(chasseur);
        int refuseParChasseur =  chasseur.emporterCargaison(20);
        System.out.println("Un vaisseau de type "+chasseur.type+" a une cargaison de "+chasseur.tonnageActuel+" tonnes, "+refuseParChasseur
        +" tonnes n'ont pas pues être chargées");

        VaisseauDeGuerre fregate = new VaisseauDeGuerre("FREGATE");
        fregate.nbPassagers = 100;
        terre.accueillirVaisseau(fregate);
        int refuseParFregate =  fregate.emporterCargaison(45);
        System.out.println("Un vaisseau de type "+fregate.type+" a une cargaison de "+fregate.tonnageActuel+" tonnes, "+refuseParFregate
                +" tonnes n'ont pas pues être chargées");
        refuseParFregate =  fregate.emporterCargaison(12);
        System.out.println("Un vaisseau de type "+fregate.type+" a une cargaison de "+fregate.tonnageActuel+" tonnes, "+refuseParFregate
                +" tonnes n'ont pas pues être chargées");

        VaisseauDeGuerre autreFregate = new VaisseauDeGuerre("FREGATE");
        autreFregate.nbPassagers = 14;
        terre.accueillirVaisseau(autreFregate);
        int refuseParAutreFregate =  autreFregate.emporterCargaison(30);
        System.out.println("Un vaisseau de type "+autreFregate.type+" a une cargaison de "+autreFregate.tonnageActuel+" tonnes, "+refuseParAutreFregate
                +" tonnes n'ont pas pues être chargées");

        terre.accueillirVaisseau(vaisseauMonde);
        int refuseParVaisseauMonde = vaisseauMonde.emporterCargaison(1560);
        System.out.println("Un vaisseau de type "+vaisseauMonde.type+" a une cargaison de "+vaisseauMonde.tonnageActuel+" tonnes, "+refuseParVaisseauMonde
                +" tonnes n'ont pas pues être chargées");
        refuseParVaisseauMonde = vaisseauMonde.emporterCargaison(600);
        System.out.println("Un vaisseau de type "+vaisseauMonde.type+" a une cargaison de "+vaisseauMonde.tonnageActuel+" tonnes, "+refuseParVaisseauMonde
                +" tonnes n'ont pas pues être chargées");
    }
}