public abstract class Planete {

    static String forme = "Sphérique";
    static int nbPlanetesDecouvertes = 0;

    String nom;
    long diametre;
    Atmosphere atmosphere = new Atmosphere();

    Planete(String nom){
        this.nom = nom;
        nbPlanetesDecouvertes++;
    }

    static String expansion(double distance){
        if(distance < 14){
            return "Oh la la mais c'est super rapide !";
        }
        else{
            return "Je rêve ou c'est plus rapide que la lumière ?";
        }
    }

    int rotation(int angle){
       return angle/360;
    }

    int revolution(int angle){
        return angle/360;
    }

}
