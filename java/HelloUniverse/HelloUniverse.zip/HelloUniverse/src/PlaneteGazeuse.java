public class PlaneteGazeuse extends Planete{

    PlaneteGazeuse(String nom){
        super(nom);
    }
}
