public class PlaneteTellurique extends Planete implements Habitable{

    Vaisseau vaisseauAccoste;
    int totalVisiteurs = 0;

    PlaneteTellurique(String nom){
        super(nom);
    }


    public Vaisseau  accueillirVaisseau(Vaisseau nouveauVaisseau){

        if(nouveauVaisseau instanceof VaisseauDeGuerre) {
            ((VaisseauDeGuerre) nouveauVaisseau).desactiverArmes();
        }
        this.totalVisiteurs += nouveauVaisseau.nbPassagers;
        Vaisseau vaisseauPrecedent = this.vaisseauAccoste;
        this.vaisseauAccoste = nouveauVaisseau;
        return vaisseauPrecedent;

    }
}
