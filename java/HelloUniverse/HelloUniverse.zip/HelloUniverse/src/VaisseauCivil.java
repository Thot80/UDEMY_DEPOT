public class VaisseauCivil extends Vaisseau {

    VaisseauCivil(String type){
        super(type);
        if(this.type.equalsIgnoreCase("CARGO")){
            this.tonnageMax = 500;
        }
        else if(this.type.equalsIgnoreCase("VAISSEAU-MONDE")){
            this.tonnageMax = 2000;
        }
    }
    @Override
    int emporterCargaison(int tonnage) {
        int tonnagePotentiel = this.tonnageMax - this.tonnageActuel;
        if(tonnage > tonnagePotentiel){
           this.tonnageActuel += tonnagePotentiel;
           return (tonnage - tonnagePotentiel);
        }
        else{
            this.tonnageActuel += tonnage;
            return 0;
        }
    }
}
