public class VaisseauDeGuerre extends Vaisseau{

    boolean armesDesactivees = false;

    VaisseauDeGuerre(String type){
        super(type);
        if(type.equalsIgnoreCase("CHASSEUR")){
            this.tonnageMax = 0;
            this.tonnageActuel = 0;
        }
        else if(type.equalsIgnoreCase("FREGATE")){
            this.tonnageMax = 50;
        }
        else if(type.equalsIgnoreCase("CROISEUR")){
            this.tonnageMax = 100;
        }
    }

    @Override
    int emporterCargaison(int tonnage) {
        int tonnagePotentiel = 0;

            if(this.nbPassagers < 12){
                this.tonnageActuel = 0;
                return tonnage;
            }
            else{
                tonnagePotentiel = (this.nbPassagers * 2 - this.tonnageActuel);
                if(tonnagePotentiel > this.tonnageMax ){
                    tonnagePotentiel = this.tonnageMax - this.tonnageActuel;
                   if(tonnage > tonnagePotentiel){
                       this.tonnageActuel += tonnagePotentiel;
                       return (tonnage - tonnagePotentiel);
                   }
                   else{
                       this.tonnageActuel += tonnage;
                       return 0;
                   }
                }
                else{
                    if(tonnage > tonnagePotentiel ){
                        this.tonnageActuel += tonnagePotentiel;
                        return(tonnage - tonnagePotentiel);
                    }
                    else{
                        this.tonnageActuel += tonnage;
                        return 0;
                    }
                }
            }
        }


    void attaque(Vaisseau cible, String arme, int duree) {

        if (this.armesDesactivees) {
            System.out.println("Attaque impossible, l'armement est désactivé");
        } else {
            System.out.println("Un vaisseau de type " + this.type + " attaque un vaisseau de type " + cible.type + " en utilisant l'arme " + arme + " pendant " + duree + " minutes");
            cible.resistanceDuBouclier = 0;
            cible.blindage = cible.blindage / 2;
        }
    }

    boolean desactiverArmes(){

        if(this.armesDesactivees){
            return this.armesDesactivees;
        }
        else{
            this.armesDesactivees = true;
            System.out.println("Désactivation des armes d'un vaisseau de type "+this.type+".");
            return this.armesDesactivees;
        }
    }

    void activerBouclier(){
        this.desactiverArmes();
        System.out.println("Activation du bouclier d'un vaisseau de type " +this.type);
    }
}
